# YouTube Transcript — Mocu extension

Retrieves a video's subtitles with `yt-dlp` (without downloading the video), converts WebVTT captions into timestamped plain text, and returns the transcript as the command result for Mocu's calling agent.

## Requirements

- Node.js 20 or newer.
- This bundle includes `yt-dlp.exe` for Windows, so no separate yt-dlp install is needed there. On macOS/Linux, install `yt-dlp` separately and make it available on `PATH`, or set the executable in **Mocu → Extensions → YouTube Transcript → Settings**.
- Internet access to YouTube. Some videos have no captions, and YouTube may restrict access to age-restricted/private/region-blocked videos.

Check yt-dlp with `yt-dlp --version`; on Windows, the bundled binary is also used automatically when `yt-dlp` isn't found on `PATH`. On other platforms install from the official documentation: <https://github.com/yt-dlp/yt-dlp#installation-and-updates>.

## Install in Mocu

1. Zip this folder so `manifest.json` is at the ZIP root (or one folder below it). Do not include `node_modules`.
2. In Mocu, open **Extensions** and install the ZIP.
3. In the extension's settings, leave `ytDlpPath` as `yt-dlp` when it is on `PATH`; otherwise set the full executable path.
4. Ask the agent for a transcript, for example: “Get the Persian transcript for https://youtu.be/VIDEO_ID”. The command is also available as `get_transcript`.

The command accepts a YouTube URL/video ID (also within a `prompt` or `text` field) and an optional `language`/`languages` field such as `"fa,en"` or `["fa", "en"]`. The default preference is English then Persian. It chooses a matching manually-created subtitle first, then tries automatic captions. Returned data includes the video title/ID, selected language and subtitle type, cue count, and timestamped transcript. Output is capped at 200,000 characters to keep responses manageable.

## Local development and checks

```powershell
npm install
npm test
node index.js
```

`node index.js` should wait quietly for Mocu's JSON-RPC input. The unit tests exercise input validation, language selection, and caption parsing; a real subtitle fetch requires network access and a reachable video with captions.
