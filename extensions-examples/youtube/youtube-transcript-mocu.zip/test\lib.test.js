import test from "node:test";
import assert from "node:assert/strict";
import { getTranscript, chooseSubtitle, normalizeLanguages, parseVideoInput, parseVtt } from "../lib.js";

const VIDEO_ID = "dQw4w9WgXcQ";

test("accepts supported YouTube URL forms and extracts URLs from prompts", () => {
  assert.deepEqual(parseVideoInput(`Please transcribe https://youtu.be/${VIDEO_ID}?si=abc`), {
    videoId: VIDEO_ID,
    url: `https://www.youtube.com/watch?v=${VIDEO_ID}`,
  });
  assert.equal(parseVideoInput({ video_url: `https://www.youtube.com/shorts/${VIDEO_ID}` }).videoId, VIDEO_ID);
  assert.equal(parseVideoInput(VIDEO_ID).videoId, VIDEO_ID);
  assert.equal(parseVideoInput(`Please summarize the video https://youtu.be/${VIDEO_ID}`).videoId, VIDEO_ID);
});

test("rejects non-YouTube hosts and malformed IDs", () => {
  assert.throws(() => parseVideoInput("https://example.com/watch?v=dQw4w9WgXcQ"), /valid YouTube/);
  assert.throws(() => parseVideoInput("too-short"), /valid YouTube/);
});

test("normalizes language preferences with a useful default", () => {
  assert.deepEqual(normalizeLanguages({ languages: "fa, en,fa" }), ["fa", "en"]);
  assert.deepEqual(normalizeLanguages({ language: ["fr", "de"] }), ["fr", "de"]);
  assert.deepEqual(normalizeLanguages({ language: "" }), ["en", "fa"]);
});

test("prefers manual captions and respects language preference", () => {
  assert.deepEqual(chooseSubtitle({
    subtitles: { "en-US": [{}], fa: [{}] },
    automatic_captions: { en: [{}] },
  }, ["en", "fa"]), { language: "en-US", type: "manual" });
  assert.deepEqual(chooseSubtitle({
    subtitles: {},
    automatic_captions: { fa: [{}] },
  }, ["en", "fa"]), { language: "fa", type: "automatic" });
  assert.throws(() => chooseSubtitle({ subtitles: {}, automatic_captions: {} }, ["en"]), /Available subtitle languages: none/);
});

test("turns WebVTT cues into timestamped plain text", () => {
  const transcript = parseVtt(`WEBVTT\n\nNOTE generated captions\nignored\n\n1\n00:00:01.000 --> 00:00:03.000 align:start\n<c>Hello &amp; welcome.</c>\n\n00:03.200 --> 00:03:04.000\nSecond line<br>continues.\n`);
  assert.equal(transcript, "[00:00:01.000] Hello & welcome.\n[00:03.200] Second line continues.");
  assert.equal(parseVtt("WEBVTT\n\n"), "");
});

test("performs a real end-to-end subtitle-only fetch and returns a transcript", {
  timeout: 120_000,
}, async (t) => {
  try {
    const result = await getTranscript({ url: `https://www.youtube.com/watch?v=${VIDEO_ID}`, languages: "en" });
    assert.equal(result.videoId, VIDEO_ID);
    assert.equal(result.language, "en");
    assert.ok(["manual", "automatic"].includes(result.subtitleType));
    assert.ok(result.cueCount > 0);
    assert.match(result.transcript, /^\[\d{2}:\d{2}:\d{2}\.\d{3}\]/);
    assert.equal(result.truncated, false);
  } catch (error) {
    if (/Unable to download webpage|network|timed out|Sign in|HTTP Error/i.test(error.message)) {
      t.skip(`Live YouTube is unavailable in this environment: ${error.message}`);
      return;
    }
    throw error;
  }
});
